from django.shortcuts import redirect
from rest_framework import generics

# Create your views here.
from books.models import Book
from .serializers import BookSerializer

class BookApiView(generics.ListAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

