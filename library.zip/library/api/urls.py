from enum import verify
from django.urls import path
from django.urls import path

import api
from .views import *

from .views import BookApiView

urlpatterns = [
    path('',BookApiView.as_view(), name='home'),
    
]
urlpatterns = [
    path('', api),
    path('',verify)
]